%% Single channel speech enhancement
clear all; close all; clc;

set(0, 'DefaultLineLineWidth', 1, ...
    'DefaultTextFontSize', 12, ...
    'DefaultAxesFontSize', 12);

%% Parameters
data.denoise_type = 'spec_sub_mag'; % 'spec_sub_power', 'spec_sub_mag', 'spec_sub_over', 'wiener', 'mmse_stsa'
data.plot = 0;

%% Generate noisy signal
speech_file = 'wav/input/female2.wav';
noise_file = 'wav/input/noise_babble.wav';
[x, fs] = wavread(speech_file);
[n, fs_noise] = wavread(noise_file);
n = resample(n, fs, fs_noise);

% Adjust input SNR using noise_gain
noise_gain = 0.7;
n = noise_gain*n(1:length(x));

y = x + n;

%% Make window
win_t = 0.03;                   % window size in seconds
win_s = round(fs*win_t);        % window size in samples
if (mod(win_s, 2)==0)           % make odd
    win_s = win_s - 1;
end
win = hann(win_s);
% normalize it so the power is equal to its length
win = win*sqrt(length(win)/sum(win.^2));

%% STFT of signal
hop_size = (win_s-1)/2; % hop size (half of window size)

num_frames = floor(length(x)/hop_size);
nfft = 8*win_s;   % over sample to prevent time aliasing of filters

data.est_Sx = zeros(nfft, num_frames); % estimate of clean speech spectrum
data.est_Pn = zeros(nfft, num_frames); % estimate of noise power spectrum
data.est_Mn = zeros(nfft, num_frames); % estimate of noise magnitude spectrum

for i = 1: num_frames
    disp(['Frame ' num2str(i)]);
    data.iteration = i;
    
    %% FFT
    s = (i-1)*hop_size + 1;                 % start index
    e = min(s+win_s-1, length(x));          % end index    
    if(mod(e-s+1,2)==0) e=e-1; end          % make length odd
    
    l = e-s+1; % length of windowed signal
    
    yzp = zpzpwin(y(s:e), win(1:l), nfft);    % zero-pad, zero-phase windowing
    xzp = zpzpwin(x(s:e), win(1:l), nfft);   
    nzp = zpzpwin(n(s:e), win(1:l), nfft);
    
    data.Sy = fft(yzp); % FFT
    data.Sx = fft(xzp); % Sx, and Sn for analysis purposes only!!
    data.Sn = fft(nzp);
    
    %% Estimate power spectrum of noise
    data = noiseEstimationSNR(data);
    
    %% Do magic!!!
    [data, est_Sx] = enhanceSpeech(data); 
%     [data, est_Sx] = enhanceSpeechFilled(data);
    data.est_Sx(:, i) = est_Sx; % for speed, set data element outside the function    

    %% Plot periodograms per frame
    if (data.plot)
        plot([1:nfft/2]/nfft*fs, 10*log10(abs(data.Sx(1:nfft/2)).^2/l), 'b'); hold on;
        plot([1:nfft/2]/nfft*fs, 10*log10(abs(data.Sy(1:nfft/2)).^2/l), 'r'); 
%         plot([1:nfft/2]/nfft*fs, 10*log10(abs(data.Sn(1:nfft/2)).^2/l), 'm'); 
        plot([1:nfft/2]/nfft*fs, 10*log10(data.est_Pn(1:nfft/2)/l), 'm--'); 
        plot([1:nfft/2]/nfft*fs, 10*log10(abs(data.est_Sx(1:nfft/2, i)).^2/l), 'g');
        legend('clean speech', 'noisy speech', 'noise estimate', 'denoised speech');
        xlabel('Freq (Hz)'); ylabel('Power magnitude (dB)'); title(['Frame ' num2str(i)]);
        axis([xlim -120 10]);
        hold off;
        pause();
    end
     
end

%% Overlap add
xhat = real(invmyspectrogram2(data.est_Sx, hop_size, win_s));
dc = sum(win(1:hop_size:end)); 
xhat = xhat/dc;

xhat = xhat(1:length(x));

%% Save wave files
wavwrite(x, fs,'wav/results/original_speech.wav');
wavwrite(y, fs,'wav/results/noisy_speech.wav');
wavwrite(xhat, fs,['wav/results/denoised_speech_' data.denoise_type '.wav']);

%% Plot spectrogram
% View with more overlap to show smoothed spectrogram
subplot(311); myspectrogram2(x,nfft,fs,win,(length(win)+1)*4/5,1, 80); title('Original speech');
subplot(312); myspectrogram2(y,nfft,fs,win,(length(win)+1)*4/5,1, 80); title('Noisy speech');
subplot(313); myspectrogram2(xhat,nfft,fs,win,(length(win)+1)*4/5,1, 80); title('Denoised speech');

%% SNR 
snr_input = 10*log10(sum(x.^2)/sum(n.^2))
snr_output = 10*log10(sum(x.^2)/sum((x-xhat').^2))

%% If you want to hear it in MATLAB
% sound(y, fs);
% sound(xhat, fs);